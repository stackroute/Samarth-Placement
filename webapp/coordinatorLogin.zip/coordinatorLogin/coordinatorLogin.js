angular.module("samarth.coordinatorlogin", [
	'ngMaterial',
	'ui.router',
	'ngMessages'])
   .config(config);
function config($stateProvider, $urlRouterProvider)
{
    $urlRouterProvider.otherwise('/');
     $stateProvider
    .state('index',{
        url: '/',
        views: {
            'appbar': {
                templateUrl: 'coordinatorLogin/template/navbar.html'

            },
            'content': {
             templateUrl: 'coordinatorLogin/template/login.html'
            }

        }

    })

    .state('index.registrationpage', {
        url:'/registrationpage',
        views: {
            'content@': {
                templateUrl: 'coordinatorLogin/template/registrationPage.html'

            }
        }

    })
        .state('index.dashboardpage', {
        url:'/dashboardpage',
        views: {
            'content@': {
          templateUrl: 'coordinatorLogin/template/dashboardPage.html',

                 controller:'signinCtrl' ,
               controlleras:'vm',
            }
        }

    })


}
